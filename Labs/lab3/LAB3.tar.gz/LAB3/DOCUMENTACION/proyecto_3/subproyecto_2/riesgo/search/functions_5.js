var searchData=
[
  ['observando',['observando',['../classprocedimientos__observador__pkg.html#a15eea4f54984be83b3ec67276014a82f',1,'procedimientos_observador_pkg.observando()'],['../class__procedimientos__observador__pkg.html#a15eea4f54984be83b3ec67276014a82f',1,'_procedimientos_observador_pkg.observando()']]]
];
