var searchData=
[
  ['fin_5ftrans',['fin_trans',['../classarbitro.html#ab38bb57f521bc32c2bb61beeebdb6801',1,'arbitro']]],
  ['finalizada',['finalizada',['../classcontrolador__pkg.html#a8ed47d5243a93d6ac1ae658dc90cb6e9',1,'controlador_pkg']]]
];
