var searchData=
[
  ['param_5fdisenyo_5fpkg_2evhd',['param_disenyo_pkg.vhd',['../param__disenyo__pkg_8vhd.html',1,'']]],
  ['param_5fmemorias_5fpkg_2evhd',['param_memorias_pkg.vhd',['../param__memorias__pkg_8vhd.html',1,'']]],
  ['procedimientos_5fcontrolador_5fpkg_2evhd',['procedimientos_controlador_pkg.vhd',['../procedimientos__controlador__pkg_8vhd.html',1,'']]],
  ['procedimientos_5fobservador_5fpkg_2evhd',['procedimientos_observador_pkg.vhd',['../procedimientos__observador__pkg_8vhd.html',1,'']]]
];
