var searchData=
[
  ['_5fprocedimientos_5fcontrolador_5fpkg',['_procedimientos_controlador_pkg',['../class__procedimientos__controlador__pkg.html',1,'']]],
  ['_5fprocedimientos_5fobservador_5fpkg',['_procedimientos_observador_pkg',['../class__procedimientos__observador__pkg.html',1,'']]]
];
