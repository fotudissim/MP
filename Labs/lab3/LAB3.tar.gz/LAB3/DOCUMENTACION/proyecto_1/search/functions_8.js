var searchData=
[
  ['transaccion_5fbus',['transaccion_bus',['../classprocedimientos__controlador__pkg.html#af31d90cc10486bea77992bbbafa3374a',1,'procedimientos_controlador_pkg.transaccion_bus()'],['../class__procedimientos__controlador__pkg.html#af31d90cc10486bea77992bbbafa3374a',1,'_procedimientos_controlador_pkg.transaccion_bus()']]]
];
